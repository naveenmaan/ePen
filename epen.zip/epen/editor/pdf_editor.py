from PyPDF2 import PdfFileReader, PdfFileWriter
from io import BytesIO
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
import base64



def createPdf(pageNumber, actions, pagesize):
    packet = BytesIO()
    can = canvas.Canvas(packet, pagesize=pagesize)

    scale = 0.666;

    for key, value in actions.items():
        if key == "pencil":
            for actionRow in value:
                for index, trackRow in enumerate(actionRow['track']):
                    if index < actionRow['trackLength']:
                        can.setStrokeColor(HexColor(actionRow['color']))
                        can.line(trackRow[0]*scale, pagesize[1] - trackRow[1]*scale,
                                 actionRow['track'][index+1][0]*scale, pagesize[1] - actionRow['track'][index+1][1]*scale)

        if key ==  "rectangle":
            for actionRow in value:
                can.setStrokeColor(HexColor(actionRow['color']))
                can.roundRect(actionRow['start'][0]*scale,  pagesize[1] - actionRow['start'][1]*scale,
                              (actionRow['end'][0]-actionRow['start'][0])*scale,
                              (actionRow['start'][1]-actionRow['end'][1])*scale, 0, stroke=1, fill=0)

        if key ==  "text":
            for actionRow in value:
                textobject = can.beginText()
                textobject.setTextOrigin(actionRow['axis'][0]*scale, pagesize[1]-actionRow['axis'][1]*scale)
                textobject.setFont('Times-Roman', 30)
                textobject.textLine(text=actionRow['comment'])
                textobject.setFillColor(colors.black)
                can.drawText(textobject)

    can.showPage()
    can.save()
    packet.seek(0)

    newPdf = PdfFileReader(packet)

    return newPdf

def applyEditing(file, actions):
    decodedText = base64.b64decode(file)
    pdfFileObj = BytesIO()
    pdfFileObj.write(decodedText)
    pdfReader = PdfFileReader(pdfFileObj)

    output = PdfFileWriter()

    for row in range(0, pdfReader.numPages):
        height = pdfReader.getPage(row).mediaBox.getHeight()
        width = pdfReader.getPage(row).mediaBox.getWidth()
        actionedPage = createPdf(pdfReader.numPages, actions, (width, height))

        page = pdfReader.getPage(row)
        page.mergePage(actionedPage.getPage(0))
        output.addPage(page)

    response = BytesIO()
    output.write(response)
    response.seek(0)

    return response