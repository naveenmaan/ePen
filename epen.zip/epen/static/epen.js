pdfjsLib.GlobalWorkerOptions.workerSrc = "../static/pdf.worker.js";

function getCookie(cname) {
  var name = cname + "=";
  var decodedCookie = decodeURIComponent(document.cookie);
  var ca = decodedCookie.split(';');
  for(var i = 0; i <ca.length; i++) {
    var c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}

$.urlParam = function(name){
    var results = new RegExp('[\?&]' + name + '=([^&#]*)').exec(window.location.href);
    if (results==null) {
       return null;
    }
    return decodeURI(results[1]) || 0;
}

var ePen = (function ePenClosure(){
    function ePen(option){
        this.url = option.url,
        this.fileID = option.fileID
        this._pencil = option._pencil || false,
        this._rectangle = option._rectangle || false,
        this._eraser = option._eraser || false,
        this._text = option._text || false,
        this._color = option._color || false,
        this.colorSelected = option.colorSelected || '#000251',
        this._cloud_download = option._cloud_download || false,
        this._scale = 1.5,
        this.pencilHistory = [],
        this.rectangleHistory = [],
        this.textHistory = [],
        this.drawOption = null,
        this.isMouseDown = option.isMouseDown || false;
    }


    ePen.prototype = {
        _load_pdf : function(){
            //pdfjsLib.getDocument(url)
            pdfjsLib.getDocument({data: atob(url),}).then(function(pdf){
                // Get div#container and cache it for later use
                var container = document.getElementById("container");
                // Loop from 1 to total_number_of_pages in PDF document
                for (var i = 1; i <= pdf.numPages; i++) {
                    // Get desired page
                    pdf.getPage(i).then(function(page) {
                        var viewport = page.getViewport(this._scale);
                        var div = document.createElement("div");

                        // Set id attribute with page-#{pdf_page_number} format
                        div.setAttribute("id", "page-" + (page.pageIndex + 1));

                        // This will keep positions of child elements as per our needs
                        div.setAttribute("style", "position: relative");

                        // Append div within div#container
                        container.appendChild(div);

                        // Create a new Canvas element
                        var canvas = document.createElement("canvas");
                        canvas.id = "canvas-" + (page.pageIndex+1).toString();

                        // Append Canvas within div#page-#{pdf_page_number}
                        div.appendChild(canvas);

                        //add another canvas to display draw
                        var showEditCanvas = document.createElement("canvas");
                        showEditCanvas.id = "show_canvas-" + (page.pageIndex+1).toString();
                        showEditCanvas.setAttribute("class", "boxCanvas");
                        showEditCanvas.height = viewport.height;
                        showEditCanvas.width = viewport.width;
                        div.appendChild(showEditCanvas);

                        //add another canvas to draw
                        var drawCanvas = document.createElement("canvas");
                        drawCanvas.id = "draw_canvas-" + (page.pageIndex+1).toString();
                        drawCanvas.setAttribute("class", "boxCanvas drawLayer");
                        drawCanvas.height = viewport.height;
                        drawCanvas.width = viewport.width;
                        drawCanvas.setAttribute("onmousemove", `ePen.prototype.drawCanvasMouseHoverEvent(event, ${page.pageIndex+1})`);
                        drawCanvas.setAttribute("onmouseout", "ePen.prototype.drawCanvasMouseOutEvent()");
                        div.appendChild(drawCanvas);

                        //add
                        var context = canvas.getContext('2d');
                        canvas.height = viewport.height;
                        canvas.width = viewport.width;

                        var renderContext = {
                            canvasContext: context,
                            viewport: viewport
                        };

                         // Render PDF page
                         page.render(renderContext)
                         .then(function() {
                            // Get text-fragments
                            return page.getTextContent();
                         })
                         .then(function(textContent){
                            // Create div which will hold text-fragments
                            var textLayerDiv = document.createElement("div");

                            // Set it's class to textLayer which have required CSS styles
                            textLayerDiv.setAttribute("class", "textLayer");

                            // Append newly created div in `div#page-#{pdf_page_number}
                            div.appendChild(textLayerDiv);

                            // Create new instance of TextLayerBuilder class
                            var textLayer = new TextLayerBuilder({
                                textLayerDiv: textLayerDiv,
                                pageIndex: page.pageIndex,
                                viewport: viewport
                            });

                            // Set text-fragments
                            textLayer.setTextContent(textContent);

                            // Render text-fragments
                            textLayer.render();

                         });

                    });
                }
            });
        },
        _load_toolbox : function(){
            $(".drawLayer").show();
            //get the toolbar container
            var toolbox_container = document.getElementById("nav-mobile");
            if(_pencil){
                $("#ipen_pencil").show()
            }
            if(_rectangle){
                $("#ipen_rectangle").show()
            }
            if(_eraser){
                $("#ipen_eraser").show()
            }
            if(_text){
                $("#ipen_text").show()
            }
            if(_color){
                $("#ipen_color").show()
            }
            if(_cloud_download){
                $("#ipen_cloud_download").show()
            }
        },
        show_canvas_rectangle: function(){
            var rectangleData = rectangleHistory[rectangleHistory.length-1];
            var page_number = rectangleData.pageNumber;
            var paintCanvas = document.getElementById( "show_canvas-"+page_number );
            var context = paintCanvas.getContext( '2d' );

            context.strokeStyle = rectangleData.color;
            context.strokeRect(rectangleData.start[0], rectangleData.start[1],
                rectangleData.end[0]-rectangleData.start[0], rectangleData.end[1]-rectangleData.start[1]);
            paintCanvas=document.getElementById( "draw_canvas-"+page_number );
            context = paintCanvas.getContext( '2d' );
            context.clearRect(0, 0, paintCanvas.width, paintCanvas.height);
        },
        drawCanvasMouseHoverEvent : function(event, page_number){

            document.addEventListener('mousedown', function(){
                isMouseDown = true;
            });

            if(drawOption=="pencil"){
                this._pencil_event_handler(page_number);
            }else if(drawOption=="rectangle"){
                this._rectangle__event_handler(page_number);
            }else if(drawOption=="text"){
                this._text_event_handler(page_number);
            }
            if(drawOption=="rectangle" && !isMouseDown){
                    if(rectangleHistory.length>0 && rectangleHistory[rectangleHistory.length-1].isAlive){
                        rectangleHistory[rectangleHistory.length-1].isAlive = false;
                        this.show_canvas_rectangle();
                    }
                }
            document.addEventListener('mouseup', function(){
                isMouseDown = false;
                if(pencilHistory.length>0 && pencilHistory[pencilHistory.length-1].isAlive){
                    pencilHistory[pencilHistory.length-1].isAlive=false;
                }

            });

            document.getElementById("draw_canvas-"+page_number).addEventListener('mousedown', function(){
                if(drawOption=="rectangle"){
                     if(rectangleHistory.length==0 || !rectangleHistory[rectangleHistory.length-1].isAlive){
                         rectangleHistory.push({
                             start: [],
                             end: [],
                             pageNumber: page_number,
                             isAlive : true,
                             color: colorSelected
                         });
                    }else if(!isMouseDown){
                        rectangleHistory[rectangleHistory.length-1].start = [event.offsetX, event.offsetY]
                        rectangleHistory[rectangleHistory.length-1].color= colorSelected
                    }
                }
            });

        },
        drawCanvasMouseOutEvent : function(){

            document.addEventListener('mouseup', function(){
                isMouseDown = false;
            });

            if(pencilHistory.length>0 && pencilHistory[pencilHistory.length-1].isAlive){
                pencilHistory[pencilHistory.length-1].isAlive=false;
            }
            if(drawOption=="rectangle"){
                if(rectangleHistory.length>0 && rectangleHistory[rectangleHistory.length-1].isAlive){
                    rectangleHistory[rectangleHistory.length-1].isAlive = false;
                    this.show_canvas_rectangle();
                }
            }
        },
        _pencil_click_event: function(){
            if (drawOption == null){
                $(".textLayer").hide();
                $(".drawLayer").show();
            }
            if (drawOption == "pencil"){
                drawOption = null;
                $(".textLayer").show();
                $(".drawLayer").hide();
            }else{
                drawOption = "pencil";
            }
        },
        _rectangle_click_event: function(){
            if (drawOption == null){
                $(".textLayer").hide();
                $(".drawLayer").show();
            }
            if (drawOption == "rectangle"){
                drawOption = null;
                $(".textLayer").show();
                $(".drawLayer").hide();
            }else{
                drawOption = "rectangle";
            }
        },
        _text_click_event: function(){
            if (drawOption == null){
                $(".textLayer").hide();
                $(".drawLayer").show();
            }
            if (drawOption == "text"){
                drawOption = null;
                $(".textLayer").show();
                $(".drawLayer").hide();
            }else{
                drawOption = "text";
            }
        },
        _pencil_event_handler: function(page_number){
            if(isMouseDown){
                var oldX=null;
                var oldY=null;
                if(pencilHistory.length==0 || !pencilHistory[pencilHistory.length-1].isAlive){
                    pencilHistory.push({
                        track: [],
                        trackLength: -1,
                        pageNumber: page_number,
                        isAlive : true,
                        color: colorSelected
                    });
                }else{
                    var history = pencilHistory[pencilHistory.length-1];
                    [oldX, oldY] = history.track[history.trackLength];
                }
                const paintCanvas = document.getElementById( "show_canvas-"+page_number );
                const context = paintCanvas.getContext( '2d' );
                context.lineCap = 'round';
                const newX = event.offsetX;
                const newY = event.offsetY;
                if (oldX == null || oldY == null){
                    pencilHistory[pencilHistory.length-1].track.push([newX, newY]);
                    pencilHistory[pencilHistory.length-1].trackLength += 1;
                    return;
                }
                context.beginPath();
                context.strokeStyle = pencilHistory[pencilHistory.length-1].color;
                context.moveTo( oldX, oldY );
                context.lineTo( newX, newY );
                context.stroke();
                pencilHistory[pencilHistory.length-1].track.push([newX, newY]);
                pencilHistory[pencilHistory.length-1].trackLength += 1;
            }else{

            }
        },
        _rectangle__event_handler: function(page_number){

            if(isMouseDown){
                if(rectangleHistory.length>0 && rectangleHistory[rectangleHistory.length-1].isAlive){}{
                    rectangleHistory[rectangleHistory.length-1].end = [event.offsetX, event.offsetY];
                    const paintCanvas = document.getElementById( "draw_canvas-"+page_number );
                    const context = paintCanvas.getContext( '2d' );
                    context.setLineDash([6]);

                    var rectangleData = rectangleHistory[rectangleHistory.length-1];

                    context.clearRect(0, 0, paintCanvas.width, paintCanvas.height);
                    context.strokeStyle = rectangleData.color;
                    context.strokeRect(rectangleData.start[0], rectangleData.start[1],
                        rectangleData.end[0]-rectangleData.start[0], rectangleData.end[1]-rectangleData.start[1]);

                }
            }
        },
        _text_event_handler: function(page_number){
            if(isMouseDown){
                axis = [event.offsetX, event.offsetY];
                var comment = prompt("Please enter your commet");
                textHistory.push({
                    axis: axis,
                    comment: comment,
                    pageNumber: page_number,
                });
                console.log(axis);
                var canvas = document.getElementById("show_canvas-"+page_number);
                var ctx = canvas.getContext("2d");
                ctx.font = "30px Times-Roman";
                ctx.fillText(comment, axis[0], axis[1]);
                this._text_click_event();
            }
        },
        _submmit_details: function(){

            jQuery('<form action="/applyChanges/" id="applyChanges" method="'+ ('post'||'post') +'" target="_blank" ></form>').appendTo('body')
            var $hidden = $("<input type='hidden' name='fileID'/>");
            $hidden.val(fileID);
            var $action = $("<input type='hidden' name='action'/>");
            $action.val(JSON.stringify({"pencil": pencilHistory, "rectangle": rectangleHistory, "text": textHistory}));
            var $cookies = $("<input type='hidden' name='csrfmiddlewaretoken'/>");
            $cookies.val(getCookie('csrftoken'));
            $('#applyChanges').append($hidden);
            $('#applyChanges').append($action);
            $('#applyChanges').append($cookies);
            $('#applyChanges').submit();


        },
        _changecolor_event: function(){
            colorSelected = $("#coloPricker").val();
        }

    }
    return ePen;
})();

$( document ).ready(function() {

    $.ajax({
        url: "/getFile/",
        type: "POST",
        data: {"fileID": $.urlParam('id')},
        success: function(response){
            if('error' in response){
                alert(response['error']);
            }else{
                pen = ePen({
                    url: response['fileData'],
                    _pencil: true,
                    _rectangle: true,
                    _eraser: true,
                    _text: true,
                    _color: true,
                    _cloud_download: true,
                    fileID: $.urlParam('id')
                });

                ePen.prototype._load_pdf()
                ePen.prototype._load_toolbox();
            }
        }
    });
});



